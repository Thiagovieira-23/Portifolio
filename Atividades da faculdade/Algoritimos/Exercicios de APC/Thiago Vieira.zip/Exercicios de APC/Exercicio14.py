# Outra pessoa (ou o próprio usuário) insere o número secreto
segredo = int(input("Digite um número de 1 a 100 (esconda da outra pessoa): "))
palpite = -1

while palpite != segredo:
    palpite = int(input("Adivinhe o número: "))

    if palpite < segredo:
        print("Tente um número maior.")
    elif palpite > segredo:
        print("Tente um número menor.")

print("Parabéns, você acertou!")
