#Usuário informa os números para fazer a soma
print('INFORME OS NÚMEROS PARA SUA SOMA')
num1=int(input('>'))
num2=int(input('>'))
#Faz o calculo da soma 
soma=num1+num2
print('O resultado é',soma)