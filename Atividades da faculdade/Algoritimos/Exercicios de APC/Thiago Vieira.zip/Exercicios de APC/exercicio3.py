#Lê o valor em metros para efetuar a conversão 
print('Informe o valor para fazer a conversão')
valor=float(input('Informe o valor em metros >'))
#faz a conversão
convert=valor*100
print(f'O valor em unidade de cm fica {convert}cm')