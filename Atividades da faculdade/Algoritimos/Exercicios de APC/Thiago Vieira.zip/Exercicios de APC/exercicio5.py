#Lê o número informado
n=int(input('Informe o número >'))
#Estrutura para ver se é positivo ou negativo 
if n>=0:
    print('É um número positivo')
else:
    print('É um número negativo')