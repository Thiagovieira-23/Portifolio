#Lê quatro notas e faz a média aritimética
print('Informe suas notas')
n1=float(input('Nota 1 >'))
n2=float(input('Nota 2 >'))
n3=float(input('Nota 3 >'))
n4=float(input('Nota 4 >'))
#faz a média 
media=(n1+n2+n3+n4)/4
print(f'A média foi de {media}')