#Fazer o loop 
n=0
for i in range(0,11):
    print('esta é a soma')
    n+=i
    print(n)
print(f"A soma dos 10 primeiros números naturais é: {n}")