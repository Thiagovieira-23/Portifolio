#Lê o número informado
n=float(input('Informe o número >'))
#Estrutura para ver se é positivo, negativo ou igual a zero  
if n>=0.1:
    print('É um número positivo')
elif n==0.0:
    print('É igual a zero ')
else:
    print('É um número negativo')